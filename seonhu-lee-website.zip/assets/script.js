
(function(){
  var root=document.documentElement; root.classList.add('js');
  try{var t=localStorage.getItem('theme'); if(t==='light'||t==='dark') root.setAttribute('data-theme',t);}catch(e){}
  document.getElementById('theme').addEventListener('click',function(){
    var cur=root.getAttribute('data-theme');
    if(!cur){cur=matchMedia('(prefers-color-scheme: dark)').matches?'dark':'light';}
    var next=cur==='dark'?'light':'dark'; root.setAttribute('data-theme',next);
    try{localStorage.setItem('theme',next);}catch(e){}
  });

  var NS='http://www.w3.org/2000/svg';
  function el(n,a,p){var e=document.createElementNS(NS,n);if(a)for(var k in a)e.setAttribute(k,a[k]);if(p)p.appendChild(e);return e;}

  /* ---------- engine simulation ---------- */
  if(document.getElementById('sim')){
    function bump(d,half){d=(((d%360)+360)%360+180)%360-180;return Math.abs(d)<half?0.5*(1+Math.cos(Math.PI*d/half)):0;}
    var RAD=Math.PI/180;
    // geometry for the large cutaway (cylinder 1)
    var CX=700,CYc=500,R=40,L=150,CEIL=250,HEADTOP=130,CAMY=40,CAM0=20,CAMH=20;
    var VAL=[{x:650,center:60,half:70},{x:750,center:265,half:75}];
    var A=document.getElementById('simA');
    function text(s,x,y,anchor){var t=el('text',{x:x,y:y,'text-anchor':anchor||'middle'},A);t.textContent=s;return t;}
    // air tank
    el('rect',{x:46,y:536,width:18,height:22,class:'s-metal'},A);el('rect',{x:156,y:536,width:18,height:22,class:'s-metal'},A);
    el('rect',{x:20,y:440,width:190,height:100,rx:48,class:'s-metal'},A);
    el('line',{x1:70,y1:440,x2:70,y2:428,stroke:'var(--s-line)','stroke-width':6},A);
    el('circle',{cx:70,cy:410,r:20,class:'s-face'},A);el('line',{x1:70,y1:410,x2:82,y2:398,class:'s-needle'},A);el('circle',{cx:70,cy:410,r:3,fill:'#0B1120'},A);
    text('Air tank',115,496);
    // hose
    var hose='M210 490 H470 Q500 490 500 460 V217 Q500 187 530 187 H560';
    el('path',{d:hose,class:'s-hose'},A);el('path',{d:hose,class:'s-hose2'},A);
    var flow=el('path',{d:hose,class:'s-flow'},A);
    // ball valve
    el('rect',{x:236,y:470,width:28,height:40,rx:5,class:'s-metal'},A);
    var lever=el('line',{x1:250,y1:490,x2:276,y2:490,class:'s-lever'},A);var leverTip=el('circle',{cx:276,cy:490,r:6,class:'s-tip'},A);
    text('Ball valve',250,534);
    // regulator
    el('rect',{x:312,y:470,width:36,height:40,rx:6,class:'s-metal'},A);
    el('path',{d:'M318 470 a12 14 0 0 1 24 0',class:'s-metal'},A);
    el('line',{x1:330,y1:456,x2:330,y2:446,stroke:'var(--s-line)','stroke-width':6},A);
    el('circle',{cx:330,cy:424,r:22,class:'s-face'},A);el('line',{x1:330,y1:424,x2:342,y2:410,class:'s-needle'},A);el('circle',{cx:330,cy:424,r:3,fill:'#0B1120'},A);
    text('Regulator',330,534);text('and gauge',330,552);
    // relief valve
    el('rect',{x:408,y:470,width:24,height:40,rx:5,class:'s-metal'},A);
    el('rect',{x:414,y:444,width:12,height:28,class:'s-metal'},A);el('rect',{x:410,y:438,width:20,height:8,rx:3,class:'s-metal'},A);
    text('Relief valve',420,534);
    // cylinder + head
    el('rect',{x:610,y:CEIL,width:180,height:200,class:'s-bore'},A);
    var chamber=el('rect',{x:611,y:CEIL+1,width:178,height:10,fill:'var(--s-air)',opacity:0},A);
    el('rect',{x:560,y:HEADTOP,width:280,height:CEIL-HEADTOP,class:'s-metal'},A);
    el('path',{d:'M560 168 H676 V250 H624 V206 H560 Z',class:'s-bore'},A);
    el('path',{d:'M840 168 H724 V250 H776 V206 H840 Z',class:'s-bore'},A);
    el('line',{x1:610,y1:CEIL,x2:610,y2:450,class:'s-wall'},A);el('line',{x1:790,y1:CEIL,x2:790,y2:450,class:'s-wall'},A);
    // valves + cams
    VAL.forEach(function(v,i){
      var pts=[];for(var b=-180;b<=180;b+=4){var r=CAM0+CAMH*bump(b,v.half);pts.push((r*Math.sin(b*RAD)).toFixed(1)+','+(r*Math.cos(b*RAD)).toFixed(1));}
      v.camG=el('g',null,A);el('polygon',{points:pts.join(' '),class:'s-cam'},v.camG);
      el('circle',{cx:v.x,cy:CAMY,r:5,class:'s-hub'},A);
      v.spring=el('polyline',{class:'s-spring'},A);
      v.ret=el('rect',{width:34,height:7,rx:2,class:'s-valve'},A);
      v.stem=el('rect',{width:8,class:'s-valve'},A);
      v.head=el('polygon',{class:'s-valve'},A);
    });
    text('Intake cam',650,-8);text('Exhaust cam',750,-8);
    text('Intake valve',550,148,'end');text('Exhaust valve',850,148,'start');
    // exhaust puffs
    var puffs=[];for(var q=0;q<6;q++)puffs.push(el('circle',{cx:850,cy:187,r:4,fill:'var(--s-rod)',opacity:0},A));
    text('Exhaust air',925,226);
    // piston + crank
    var pistonG=el('g',null,A);
    el('rect',{x:618,y:-28,width:164,height:56,rx:6,class:'s-piston'},pistonG);
    el('line',{x1:618,x2:782,y1:-19,y2:-19,class:'s-pl'},pistonG);el('line',{x1:618,x2:782,y1:-12,y2:-12,class:'s-pl'},pistonG);
    el('circle',{cx:CX,cy:0,r:8,fill:'#0B1120'},pistonG);
    el('circle',{cx:CX,cy:CYc,r:R+12,class:'s-crank'},A);
    var rod=el('line',{class:'s-rod'},A);
    var web=el('line',{x1:CX,y1:CYc,class:'s-web'},A);
    var cpin=el('circle',{r:11,class:'s-pin'},A);
    el('circle',{cx:CX,cy:CYc,r:15,class:'s-hub'},A);
    text('Piston',806,336,'start');text('Crankshaft',CX,584);
    // small four-cylinder view
    var B=document.getElementById('simB'),pins=[0,180,180,0],bx=[120,360,600,840],b=[];
    function elB(n,a,p){var e=document.createElementNS(NS,n);for(var k in a)e.setAttribute(k,a[k]);(p||B).appendChild(e);return e;}
    var r2=30,l2=95,cy2=205,ceil2=44;
    for(var i=0;i<4;i++){
      var x=bx[i];
      elB('rect',{x:x-52,y:ceil2,width:104,height:140,fill:'#0B1120'});
      var ch=elB('rect',{x:x-51,y:ceil2+1,width:102,height:10,fill:'#4CC3FF',opacity:0});
      elB('rect',{x:x-58,y:ceil2-14,width:116,height:16,fill:'#27324D',stroke:'#8795B3','stroke-width':1.5,rx:3});
      elB('line',{x1:x-52,y1:ceil2,x2:x-52,y2:190,stroke:'#8795B3','stroke-width':2});elB('line',{x1:x+52,y1:ceil2,x2:x+52,y2:190,stroke:'#8795B3','stroke-width':2});
      elB('circle',{cx:x,cy:cy2,r:r2+10,fill:'rgba(255,79,154,.14)',stroke:'#FF4F9A','stroke-width':2});
      var rd=elB('line',{stroke:'#FF8A3D','stroke-width':8,'stroke-linecap':'round'});
      var wb=elB('line',{x1:x,y1:cy2,stroke:'#FF4F9A','stroke-width':13,'stroke-linecap':'round'});
      var pn=elB('circle',{r:9,fill:'#FF4F9A',stroke:'#0F1626','stroke-width':3});
      elB('circle',{cx:x,cy:cy2,r:12,fill:'#E9EDF6'});
      var pg=elB('g');
      elB('rect',{x:x-46,y:-22,width:92,height:44,rx:5,fill:'#E9EDF6',stroke:'#0B1120','stroke-width':2},pg);
      elB('line',{x1:x-46,x2:x+46,y1:-14,y2:-14,stroke:'#0B1120','stroke-width':1.4},pg);elB('line',{x1:x-46,x2:x+46,y1:-8,y2:-8,stroke:'#0B1120','stroke-width':1.4},pg);
      elB('circle',{cx:x,cy:4,r:6,fill:'#0B1120'},pg);
      b.push({x:x,rod:rd,web:wb,pin:pn,pg:pg,ch:ch});
    }
    var ul=document.getElementById('strokes'),lis=[];
    for(var j=0;j<4;j++){var li=document.createElement('li');li.innerHTML='<span>Cylinder '+(j+1)+'</span><b></b>';ul.appendChild(li);lis.push(li);}
    function pinYAt(cy,r,l,a){return cy-r*Math.cos(a)-Math.sqrt(l*l-r*r*Math.sin(a)*Math.sin(a));}
    var theta=0,rpmSet=30,rpmNow=30,playing=true,ballOpen=true,last=null,visible=true,flowOff=0,tms=0;
    var readout=document.getElementById('readout');
    function state(phi){ // phi: crank angle from TDC, 0..360
      if(phi>=350||phi<130)return 'Air in'; if(phi<190)return 'Expanding'; if(phi<340)return 'Air out'; return 'Closing';
    }
    function draw(dt){
      var a=theta*RAD, sa=Math.sin(a), ca=Math.cos(a);
      // big cutaway
      var li=CAMH*bump(theta-VAL[0].center,VAL[0].half), le=CAMH*bump(theta-VAL[1].center,VAL[1].half);
      var lifts=[li,le];
      VAL.forEach(function(v,i){
        var l=lifts[i],top=CAMY+CAM0+l,x=v.x;
        v.camG.setAttribute('transform','translate('+x+','+CAMY+') rotate('+(theta-v.center)+')');
        v.stem.setAttribute('x',x-4);v.stem.setAttribute('y',top);v.stem.setAttribute('height',(236+l)-top);
        v.ret.setAttribute('x',x-17);v.ret.setAttribute('y',top+22);
        v.head.setAttribute('points',(x-4)+','+(236+l)+' '+(x+4)+','+(236+l)+' '+(x+30)+','+(250+l)+' '+(x-30)+','+(250+l));
        var y1=top+29,y2=HEADTOP,pts=[x+','+y1],n=7;
        for(var k=1;k<=n;k++){pts.push((x+(k%2?-12:12))+','+(y1+(y2-y1)*k/(n+1)));}
        pts.push(x+','+y2);v.spring.setAttribute('points',pts.join(' '));
      });
      var pinY=pinYAt(CYc,R,L,a),px=CX+R*sa,py=CYc-R*ca,pTop=pinY-28;
      pistonG.setAttribute('transform','translate(0,'+pinY+')');
      rod.setAttribute('x1',px);rod.setAttribute('y1',py);rod.setAttribute('x2',CX);rod.setAttribute('y2',pinY);
      web.setAttribute('x2',px);web.setAttribute('y2',py);cpin.setAttribute('cx',px);cpin.setAttribute('cy',py);
      var H=Math.max(2,pTop-(CEIL+1)),alpha=0;
      if(ballOpen){
        if(li>1)alpha=0.5; else if(le>1)alpha=0.1; else if(theta>=130&&theta<190){var Hc=pinYAt(CYc,R,L,130*RAD)-28-(CEIL+1);alpha=0.5*Math.min(1,Hc/H);} 
      }
      chamber.setAttribute('height',H);chamber.setAttribute('opacity',alpha.toFixed(2));
      // flow along hose
      if(ballOpen&&li>2){flowOff-=dt*140;flow.setAttribute('stroke-dashoffset',flowOff);flow.setAttribute('opacity',Math.min(1,li/6));}else{flow.setAttribute('opacity',0);}
      // exhaust puffs
      tms+=dt;
      for(var q=0;q<puffs.length;q++){
        if(le>2){var p=((tms*0.9)+q/puffs.length)%1;puffs[q].setAttribute('cx',845+p*105);puffs[q].setAttribute('cy',187-p*8+Math.sin(q*2+tms*3)*3);puffs[q].setAttribute('r',3+p*7);puffs[q].setAttribute('opacity',(0.7*(1-p)*Math.min(1,le/6)).toFixed(2));}
        else puffs[q].setAttribute('opacity',0);
      }
      // four-cylinder view
      for(var i=0;i<4;i++){
        var c=b[i],phi=(((theta-pins[i])%360)+360)%360,aa=phi*RAD;
        var ppx=c.x+r2*Math.sin(aa),ppy=cy2-r2*Math.cos(aa),pY=pinYAt(cy2,r2,l2,aa);
        c.pg.setAttribute('transform','translate(0,'+pY+')');
        c.rod.setAttribute('x1',ppx);c.rod.setAttribute('y1',ppy);c.rod.setAttribute('x2',c.x);c.rod.setAttribute('y2',pY);
        c.web.setAttribute('x2',ppx);c.web.setAttribute('y2',ppy);c.pin.setAttribute('cx',ppx);c.pin.setAttribute('cy',ppy);
        var s=ballOpen?state(phi):'Air off',al=0,hh=Math.max(2,pY-22-(ceil2+1));
        if(ballOpen){if(s==='Air in')al=0.5;else if(s==='Air out')al=0.1;else if(s==='Expanding'){var h130=pinYAt(cy2,r2,l2,130*RAD)-22-(ceil2+1);al=0.5*Math.min(1,h130/hh);}}
        c.ch.setAttribute('height',hh);c.ch.setAttribute('opacity',al.toFixed(2));
        if(lis[i].getAttribute('data-s')!==s){lis[i].setAttribute('data-s',s);lis[i].querySelector('b').textContent=s;}
      }
      readout.textContent=(ballOpen?'Air on':'Air off')+', '+Math.round(rpmNow)+' RPM, crank angle '+Math.round(theta)+'°';
    }
    function setLever(open){lever.setAttribute('x2',open?276:250);lever.setAttribute('y2',open?490:464);leverTip.setAttribute('cx',open?276:250);leverTip.setAttribute('cy',open?490:464);}
    function tick(ts){
      if(last===null)last=ts; var dt=Math.min(ts-last,64)/1000; last=ts;
      if(playing&&visible){
        var target=ballOpen?rpmSet:0; rpmNow+=(target-rpmNow)*Math.min(1,dt*(ballOpen?3:2.2)); if(!ballOpen&&rpmNow<0.4)rpmNow=0;
        theta=(theta+rpmNow*6*dt)%360; draw(dt);
      }
      requestAnimationFrame(tick);
    }
    var playBtn=document.getElementById('play'),ballBtn=document.getElementById('ball'),rpmIn=document.getElementById('rpm'),rpmOut=document.getElementById('rpmout');
    function setPlay(v){playing=v;playBtn.textContent=v?'Pause':'Play';playBtn.setAttribute('aria-pressed',String(v));}
    playBtn.addEventListener('click',function(){setPlay(!playing);});
    ballBtn.addEventListener('click',function(){ballOpen=!ballOpen;ballBtn.textContent=ballOpen?'Close ball valve':'Open ball valve';ballBtn.setAttribute('aria-pressed',String(!ballOpen));setLever(ballOpen);if(!playing)draw(0);});
    rpmIn.addEventListener('input',function(){rpmSet=+rpmIn.value;rpmOut.textContent=rpmSet+' RPM';});
    if(matchMedia('(prefers-reduced-motion: reduce)').matches){setPlay(false);}
    if('IntersectionObserver' in window){new IntersectionObserver(function(es){visible=es[0].isIntersecting;},{threshold:0}).observe(document.getElementById('sim'));}
    function fitView(){A.setAttribute('viewBox',innerWidth<720?'466 -24 510 612':'0 -24 1000 612');}
    fitView();addEventListener('resize',fitView);
    setLever(true);draw(0);requestAnimationFrame(tick);


  }
  /* ---------- wafer map ---------- */
  if(document.getElementById('wf1')){
    function drawWafer(svg,animated){
      var C=260,RW=244,id=svg.id,defs=el('defs',null,svg);
      var rg=el('radialGradient',{id:id+'rg',cx:'38%',cy:'30%',r:'85%'},defs);
      [['0','#9DB1E2'],['0.5','#40558F'],['1','#131D3A']].forEach(function(t){el('stop',{offset:t[0],'stop-color':t[1]},rg);});
      var lg=el('linearGradient',{id:id+'lg',x1:'40',y1:'40',x2:'480',y2:'480',gradientUnits:'userSpaceOnUse'},defs);
      [['0','#4CC3FF',.55],['0.35','#7C5CFF',.45],['0.65','#E8812F',.38],['1','#2457FF',.5]].forEach(function(t){el('stop',{offset:t[0],'stop-color':t[1],'stop-opacity':t[2]},lg);});
      var bg=el('linearGradient',{id:id+'bg',x1:'0',y1:'0',x2:'1',y2:'0'},defs);
      [['0','#9BE3FF',0],['0.5','#C8F1FF',.95],['1','#9BE3FF',0]].forEach(function(t){el('stop',{offset:t[0],'stop-color':t[1],'stop-opacity':t[2]},bg);});
      var cp=el('clipPath',{id:id+'cp'},defs);el('circle',{cx:C,cy:C,r:RW-2},cp);
      el('circle',{cx:C,cy:C,r:RW,fill:'url(#'+id+'rg)'},svg);
      el('circle',{cx:C,cy:C,r:RW,fill:'url(#'+id+'lg)',opacity:.55,style:'mix-blend-mode:screen'},svg);
      var g=el('g',{'clip-path':'url(#'+id+'cp)'},svg),dies=[];
      for(var iy=-11;iy<=11;iy++)for(var ix=-9;ix<=9;ix++){
        var dx=Math.abs(ix*28)+13,dy=Math.abs(iy*22)+10;
        if(Math.sqrt(dx*dx+dy*dy)<=RW-14)dies.push({x:C+ix*28,y:C+iy*22});
      }
      dies.forEach(function(d){el('rect',{x:d.x-13,y:d.y-10,width:26,height:20,fill:'rgba(255,255,255,.05)',stroke:'rgba(255,255,255,.26)','stroke-width':1},g);});
      var seed=11;function rnd(){seed=(seed*1664525+1013904223)%4294967296;return seed/4294967296;}
      var flags=[],used={};
      while(flags.length<9){var k=Math.floor(rnd()*dies.length);if(used[k])continue;used[k]=1;var d=dies[k];
        var r=el('rect',{x:d.x-13,y:d.y-10,width:26,height:20,fill:'#E8812F',stroke:'#FFE2C6','stroke-width':1.5,opacity:animated?0:1},g);flags.push({x:d.x,el:r});}
      var beam=el('g',{opacity:0},g);
      el('rect',{x:-34,y:0,width:68,height:520,fill:'url(#'+id+'bg)',opacity:.4},beam);
      el('rect',{x:-2.5,y:0,width:5,height:520,fill:'#D6F4FF',opacity:.95},beam);
      el('circle',{cx:C,cy:C,r:RW,fill:'none',stroke:'rgba(255,255,255,.4)','stroke-width':2},svg);
      el('circle',{cx:C,cy:C+RW,r:11,fill:'#0A1020'},svg);
      [[14,14,1,1],[506,14,-1,1],[14,506,1,-1],[506,506,-1,-1]].forEach(function(m){
        el('path',{d:'M'+m[0]+' '+(m[1]+m[3]*22)+'V'+m[1]+'H'+(m[0]+m[2]*22),fill:'none',stroke:'rgba(255,255,255,.4)','stroke-width':2},svg);});
      return {dies:dies.length,flags:flags,beam:beam,total:flags.length};
    }
    var W1=drawWafer(document.getElementById('wf1'),true),W2=drawWafer(document.getElementById('wf2'),false);
    var wcap=document.getElementById('wcap'),wReduce=matchMedia('(prefers-reduced-motion: reduce)').matches,wVisible=true,wt=0,wlast=null;
    function wDraw(){
      var cyc=wt%6.8,bx=-34+(560)*Math.min(1,cyc/5.6),n=0;
      W1.beam.setAttribute('transform','translate('+bx+',0)');W1.beam.setAttribute('opacity',cyc<5.8?1:0);
      W1.flags.forEach(function(f){var o=cyc>=5.6&&cyc<6.8?1:Math.max(0,Math.min(1,(bx-f.x)/20));f.el.setAttribute('opacity',o.toFixed(2));if(o>.9)n++;});
      wcap.textContent='Illustration: wafer inspection scan. Dies flagged '+n+' of '+W1.dies;
    }
    if(wReduce){W1.flags.forEach(function(f){f.el.setAttribute('opacity',1);});wcap.textContent='Illustration: wafer inspection scan. Dies flagged '+W1.total+' of '+W1.dies;}
    else{
      if('IntersectionObserver' in window){new IntersectionObserver(function(es){wVisible=es[0].isIntersecting;},{threshold:0}).observe(document.getElementById('wf1'));}
      (function wtick(ts){if(wlast===null)wlast=ts;var dt=Math.min(ts-wlast,64)/1000;wlast=ts;if(wVisible){wt+=dt;wDraw();}requestAnimationFrame(wtick);})(performance.now());
    }


  }
  /* ---------- battlebot illustration ---------- */
  (function(){
    var svg=document.getElementById('bbIll'); if(!svg)return;
    var defs=el('defs',null,svg);
    var rg=el('radialGradient',{id:'bbrg',cx:'30%',cy:'38%',r:'75%'},defs);
    [['0','#24345F'],['0.6','#101A33'],['1','#070D1A']].forEach(function(t){el('stop',{offset:t[0],'stop-color':t[1]},rg);});
    var bg=el('linearGradient',{id:'bbbeam',x1:'0',y1:'0',x2:'0',y2:'1'},defs);
    [['0','#9BE3FF',0],['0.5','#C8F1FF',.9],['1','#9BE3FF',0]].forEach(function(t){el('stop',{offset:t[0],'stop-color':t[1],'stop-opacity':t[2]},bg);});
    el('rect',{x:0,y:0,width:640,height:520,fill:'url(#bbrg)'},svg);
    var lines=el('g',{stroke:'rgba(255,255,255,.05)','stroke-width':1},svg);
    for(var gx=0;gx<=640;gx+=40)el('line',{x1:gx,y1:0,x2:gx,y2:520},lines);
    for(var gy=0;gy<=520;gy+=40)el('line',{x1:0,y1:gy,x2:640,y2:gy},lines);
    var body=el('g',{fill:'none',stroke:'#9FB0D4','stroke-width':2.5},svg);
    el('rect',{x:150,y:170,width:340,height:180,rx:16},body);
    el('line',{x1:60,y1:260,x2:580,y2:260,'stroke-dasharray':'2 8','stroke-width':1.5},body);
    el('path',{d:'M150 186 L72 260 L150 334 Z',fill:'rgba(108,140,255,.16)',stroke:'#6C8CFF'},body);
    [[150,260],[490,260]].forEach(function(p){
      el('circle',{cx:p[0],cy:p[1]-90,r:30},body);el('circle',{cx:p[0],cy:p[1]-90,r:9,fill:'#9FB0D4',stroke:'none'},body);
      el('circle',{cx:p[0],cy:p[1]+90,r:30},body);el('circle',{cx:p[0],cy:p[1]+90,r:9,fill:'#9FB0D4',stroke:'none'},body);
    });
    el('path',{d:'M490 198 L556 184 L548 214 L490 222 Z',fill:'#E8812F',stroke:'#FFD9AE'},body);
    el('path',{d:'M490 298 L556 312 L548 282 L490 274 Z',fill:'#E8812F',stroke:'#FFD9AE'},body);
    [[90,110],[550,110],[90,410],[550,410]].forEach(function(c){
      var dx=c[0]<320?22:-22, dy=c[1]<260?22:-22;
      el('path',{d:'M'+c[0]+' '+(c[1]+dy)+'V'+c[1]+'H'+(c[0]+dx),fill:'none',stroke:'rgba(255,255,255,.4)','stroke-width':2},svg);
    });
    var beamG=el('g',{},svg);
    el('rect',{x:-30,y:140,width:60,height:240,fill:'url(#bbbeam)',opacity:.5},beamG);
    el('rect',{x:-2,y:140,width:4,height:240,fill:'#D6F4FF'},beamG);
    var reduce=matchMedia('(prefers-reduced-motion: reduce)').matches,vis=true,t0=0,last=null;
    if('IntersectionObserver' in window){new IntersectionObserver(function(e){vis=e[0].isIntersecting;},{threshold:0}).observe(svg);}
    function frame(ts){
      if(last===null)last=ts; var dt=Math.min(ts-last,64)/1000; last=ts;
      if(vis&&!reduce){t0+=dt; var cyc=t0%4.6,x=-30+660*Math.min(1,cyc/4.2);beamG.setAttribute('transform','translate('+x+',0)');beamG.setAttribute('opacity',cyc<4.3?1:0);}
      requestAnimationFrame(frame);
    }
    if(reduce)beamG.setAttribute('opacity',0); else requestAnimationFrame(frame);
  })();

  /* ---------- engine illustration ---------- */
  (function(){
    var svg=document.getElementById('engIll'); if(!svg)return;
    var defs=el('defs',null,svg);
    var rg=el('radialGradient',{id:'engrg',cx:'62%',cy:'40%',r:'75%'},defs);
    [['0','#2A2440'],['0.6','#121327'],['1','#070D1A']].forEach(function(t){el('stop',{offset:t[0],'stop-color':t[1]},rg);});
    el('rect',{x:0,y:0,width:640,height:400,fill:'url(#engrg)'},svg);
    var lines=el('g',{stroke:'rgba(255,255,255,.05)','stroke-width':1},svg);
    for(var gx=0;gx<=640;gx+=40)el('line',{x1:gx,y1:0,x2:gx,y2:400},lines);
    for(var gy=0;gy<=400;gy+=40)el('line',{x1:0,y1:gy,x2:640,y2:gy},lines);
    [[40,20],[600,20],[40,380],[600,380]].forEach(function(c){
      var dx=c[0]<320?22:-22, dy=c[1]<200?22:-22;
      el('path',{d:'M'+c[0]+' '+(c[1]+dy)+'V'+c[1]+'H'+(c[0]+dx),fill:'none',stroke:'rgba(255,255,255,.4)','stroke-width':2},svg);
    });
    var bx=[150,270,390,510],cy=250,r=26,l=78,ceil=70,mount=el('g',null,svg);
    for(var i=0;i<4;i++){
      var x=bx[i];
      el('rect',{x:x-38,y:ceil,width:76,height:112,fill:'#0A1020'},mount);
      el('rect',{x:x-44,y:ceil-12,width:88,height:14,rx:3,fill:'#2A3450',stroke:'#5B6A8C','stroke-width':1.3},mount);
      el('line',{x1:x-38,y1:ceil,x2:x-38,y2:cy+10,stroke:'#5B6A8C','stroke-width':1.6},mount);
      el('line',{x1:x+38,y1:ceil,x2:x+38,y2:cy+10,stroke:'#5B6A8C','stroke-width':1.6},mount);
    }
    var parts=[],pins=[0,180,180,0];
    for(var i=0;i<4;i++){
      var x=bx[i];
      el('circle',{cx:x,cy:cy,r:r+9,fill:'rgba(108,140,255,.14)',stroke:'#6C8CFF','stroke-width':2},mount);
      var rod=el('line',{stroke:'#E8812F','stroke-width':7,'stroke-linecap':'round'},mount);
      var web=el('line',{x1:x,y1:cy,stroke:'#6C8CFF','stroke-width':11,'stroke-linecap':'round'},mount);
      var pin=el('circle',{r:7.5,fill:'#6C8CFF',stroke:'#0A1020','stroke-width':2.5},mount);
      el('circle',{cx:x,cy:cy,r:10,fill:'#DCE3F2'},mount);
      var pg=el('g',null,mount);
      el('rect',{x:x-32,y:-18,width:64,height:36,rx:4,fill:'#DCE3F2',stroke:'#0A1020','stroke-width':1.6},pg);
      el('line',{x1:x-32,x2:x+32,y1:-11,y2:-11,stroke:'#0A1020','stroke-width':1.2},pg);
      el('line',{x1:x-32,x2:x+32,y1:-5,y2:-5,stroke:'#0A1020','stroke-width':1.2},pg);
      el('circle',{cx:x,cy:4,r:5,fill:'#0A1020'},pg);
      parts.push({x:x,rod:rod,web:web,pin:pin,pg:pg});
    }
    function pinYAt(cyc,r,l,a){return cyc-r*Math.cos(a)-Math.sqrt(l*l-r*r*Math.sin(a)*Math.sin(a));}
    var theta=0,reduce=matchMedia('(prefers-reduced-motion: reduce)').matches,vis=true,last=null;
    function draw(){
      for(var i=0;i<4;i++){
        var p=parts[i],a=(theta-pins[i])*Math.PI/180,px=p.x+r*Math.sin(a),py=cy-r*Math.cos(a),pinY=pinYAt(cy,r,l,a);
        p.rod.setAttribute('x1',px);p.rod.setAttribute('y1',py);p.rod.setAttribute('x2',p.x);p.rod.setAttribute('y2',pinY+5);
        p.web.setAttribute('x2',px);p.web.setAttribute('y2',py);p.pin.setAttribute('cx',px);p.pin.setAttribute('cy',py);
        p.pg.setAttribute('transform','translate(0,'+pinY+')');
      }
    }
    if('IntersectionObserver' in window){new IntersectionObserver(function(e){vis=e[0].isIntersecting;},{threshold:0}).observe(svg);}
    function frame(ts){
      if(last===null)last=ts; var dt=Math.min(ts-last,64)/1000; last=ts;
      if(vis&&!reduce){theta=(theta+8*6*dt)%360;draw();}
      requestAnimationFrame(frame);
    }
    draw(); if(!reduce)requestAnimationFrame(frame);
  })();

  /* ---------- compare slider ---------- */
  var cmp=document.getElementById('compare');
  if(cmp){var ci=cmp.querySelector('input');ci.addEventListener('input',function(){cmp.style.setProperty('--pos',ci.value+'%');});}
  /* ---------- tabs ---------- */
  var tabs=[].slice.call(document.querySelectorAll('[role=tab]'));
  if(tabs.length){
    var show=function(t){tabs.forEach(function(x){var on=x===t;x.setAttribute('aria-selected',on);x.tabIndex=on?0:-1;var p=document.getElementById(x.getAttribute('aria-controls'));if(on)p.removeAttribute('hidden');else p.setAttribute('hidden','');});};
    tabs.forEach(function(t,i){
      t.addEventListener('click',function(){show(t);});
      t.addEventListener('keydown',function(e){
        var n=null;if(e.key==='ArrowRight')n=tabs[(i+1)%tabs.length];if(e.key==='ArrowLeft')n=tabs[(i-1+tabs.length)%tabs.length];
        if(e.key==='Home')n=tabs[0];if(e.key==='End')n=tabs[tabs.length-1];
        if(n){e.preventDefault();n.focus();show(n);}
      });
    });
    show(tabs[0]);
    [].forEach.call(document.querySelectorAll('[data-open-tab]'),function(b){b.addEventListener('click',function(){var t=document.getElementById(b.getAttribute('data-open-tab'));show(t);document.getElementById('tabs').scrollIntoView({behavior:'smooth'});});});
  }
  /* ---------- lightbox ---------- */
  var lb=document.getElementById('lb'),lbi=document.getElementById('lbi'),lbc=document.getElementById('lbc');
  document.addEventListener('click',function(e){
    var im=e.target.closest&&e.target.closest('img[data-zoom]'); if(!im)return;
    lbi.src=im.src;lbi.alt=im.alt;var f=im.closest('figure');lbc.textContent=f&&f.querySelector('figcaption')?f.querySelector('figcaption').textContent:im.alt;
    if(lb.showModal)lb.showModal();else lb.setAttribute('open','');
  });
  function close(){if(lb.close)lb.close();else lb.removeAttribute('open');}
  lb.addEventListener('click',function(e){if(e.target!==lbc)close();});
  document.getElementById('lbx').addEventListener('click',close);
})();
